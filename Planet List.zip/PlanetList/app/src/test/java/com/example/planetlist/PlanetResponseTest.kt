package com.example.planetlist

import org.junit.Assert.*
import org.junit.Test

class PlanetResponseTest{
    @Test
    fun testPlanet(){
        val planetResponse = PlanetResponse(
            Id = 1,
            name = "Sathish",
            shortDescription ="ytfgg",
            imageUrl = "",
            distanceFromSun = 100.5
        )
        val res = planetResponse.createPlanetData()
        assertEquals("Sathish", res.name)
        assertEquals("ytfgg", res.description)
    }
}