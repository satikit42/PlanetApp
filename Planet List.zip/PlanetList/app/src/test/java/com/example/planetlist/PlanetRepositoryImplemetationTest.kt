package com.example.planetlist

import android.os.Build.ID
import io.mockk.coEvery
import io.mockk.mockk
import io.mockk.mockkClass
import kotlinx.coroutines.test.TestCoroutineDispatcher
import kotlinx.coroutines.test.runBlockingTest
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

class PlanetRepositoryImplemetationTest {
    lateinit var planetRetrofitService: PlanetRetrofitService
    lateinit var planetRepo: PlanetRepositoryImplemetation
    private val testDispatcher = TestCoroutineDispatcher()
    @Before
    fun setUp(){
        planetRetrofitService = mockk{
            coEvery { getPlanetfromAPI() } returns emptyList()
        }
        planetRepo = PlanetRepositoryImplemetation(planetRetrofitService,testDispatcher)
    }
    @Test
    fun getPlanetList() =testDispatcher.runBlockingTest {
        val response = planetRepo.getPlanetList()
        assertEquals(0,response.size)
    }

    @Test
    fun gettwoPlanetList() = testDispatcher.runBlockingTest {
         coEvery { planetRetrofitService.getPlanetfromAPI() } returns (1..2).map {
             PlanetResponse(
                 Id = 0,
                 name = "Sathish",
                 shortDescription = "",
                 imageUrl = "",
                 distanceFromSun = 1.5
             )
         }
        val response = planetRepo.getPlanetList()
        assertEquals(2,response.size)
         }


    }


