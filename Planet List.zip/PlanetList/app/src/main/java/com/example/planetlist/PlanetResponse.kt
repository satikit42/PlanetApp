package com.example.planetlist
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
@Parcelize
data class PlanetResponse(
    val Id: Int,
    val name: String,
    val shortDescription: String,
    val imageUrl: String,
    val distanceFromSun: Double

): Parcelable {
    fun createPlanetData(): PlanetData{
        return PlanetData(name = this.name,description = this.shortDescription)
    }
}