package com.example.planetlist

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import retrofit2.http.GET

class PlanetListViewModel : ViewModel(){
    private val planetRepository: PlanetRepository = PlanetRepositoryImplemetation(RetrofitClient.getService(),
        Dispatchers.IO)

    private  val _viewState = MutableLiveData<PlanetListViewState>()
    val viewState: LiveData<PlanetListViewState>
    get() = _viewState
    fun initialise() {

        viewModelScope.launch {
            val planetListTemporary = planetRepository.getPlanetList()
            _viewState.value = PlanetListViewState(planentList = planetListTemporary)
        }
    }
}
