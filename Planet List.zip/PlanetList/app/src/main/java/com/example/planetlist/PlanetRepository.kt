package com.example.planetlist

interface PlanetRepository {
    suspend fun getPlanetList(): List<PlanetData>
}
