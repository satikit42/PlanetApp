package com.example.planetlist

import retrofit2.http.GET

interface PlanetRetrofitService {
    @GET("training/planets")
    suspend fun getPlanetfromAPI(): List<PlanetResponse>
}