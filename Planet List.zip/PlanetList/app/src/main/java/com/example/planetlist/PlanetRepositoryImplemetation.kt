package com.example.planetlist

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PlanetRepositoryImplemetation(val planetService: PlanetRetrofitService, val dispatcher: CoroutineDispatcher) : PlanetRepository{
    override suspend fun getPlanetList(): List<PlanetData> {

        return withContext(dispatcher) {

            planetService.getPlanetfromAPI().map{

                it.createPlanetData()
            }

        }
    }
}
