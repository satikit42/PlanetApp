package com.example.planetlist

data class PlanetListViewState(
    val title: String = "Planets",
    val planentList: List<PlanetData>
)