import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.planetlist.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.planet_list.*
import kotlinx.android.synthetic.main.planet_list.view.*

class ListFragment : Fragment(), PlanetListener {
    private val viewModel: PlanetListViewModel by viewModels()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.planet_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.viewState.observe(viewLifecycleOwner, Observer {

            var viewAdapter = RecycleAdapter(it.planentList ,this);
            planet_list // this is xml id
                .apply {
                    setHasFixedSize(true)
                    // specify an viewAdapter (see also next example)
                    adapter = viewAdapter
                }
        })
        viewModel.initialise()

        var layoutManager = LinearLayoutManager(requireContext())
        view.planet_list.layoutManager = layoutManager

    }

    override fun onPlanetTapped(planet: PlanetData) {
        findNavController().navigate(ListFragmentDirections.actionListFragmentToDetailFragment(planet))
    }
}
interface PlanetListener{
    fun onPlanetTapped(planet: PlanetData)
}